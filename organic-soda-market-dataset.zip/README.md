# Organic Soda Market – Structured Dataset

This repository contains a structured dataset derived from publicly available information from the Organic Soda Market report on NextMSC.

## Files Included
- **market_overview.csv** – Contains estimated market size & notes.
- **segmentation.csv** – Contains market segmentation across product types, sweeteners, packaging, and distribution channels.
- **metadata.json** – Metadata for the dataset including source URL.
- **README.md** – Documentation and usage guidelines.

## Source
Report: https://www.nextmsc.com/report/organic-soda-market-rc3589

## Usage
This dataset is suitable for:
- Market research  
- Academic work  
- Forecast modeling  
- Dashboard creation  
